<?php
/**
 * Giga AI - Rapid Messenger Bot Framework
 *
 * @package  GigaAI
 * @author   Binaty <hello@binaty.org>
 * @version  2.0.2
 */

// Load the bot instance
$bot = require_once __DIR__ . '/../bootstrap/bot.php';

// Run the bot
$bot->run();

