<?php

namespace Api\Model;
use \Illuminate\Database\Eloquent\Model;

class Product extends Model {

    public $table = "salesforce.product2";
    public $timestamps = false;
}