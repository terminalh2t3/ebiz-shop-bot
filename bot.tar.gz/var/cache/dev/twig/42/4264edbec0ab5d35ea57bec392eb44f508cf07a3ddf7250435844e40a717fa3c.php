<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_b3e341508bbc412126b07779e27151d6af7849e0ff61776d4458baa3c8cbe3dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f79cd8db8a8d254068fa052e32d17ada348d6dbca0312a89df2b4217282ffe8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f79cd8db8a8d254068fa052e32d17ada348d6dbca0312a89df2b4217282ffe8c->enter($__internal_f79cd8db8a8d254068fa052e32d17ada348d6dbca0312a89df2b4217282ffe8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_f79cd8db8a8d254068fa052e32d17ada348d6dbca0312a89df2b4217282ffe8c->leave($__internal_f79cd8db8a8d254068fa052e32d17ada348d6dbca0312a89df2b4217282ffe8c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Users/vu/projects/phpbot/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
