<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_f9d0643677e54094d23d82b3ea78f8acc0aeccb706212c05826a7854cf29aff7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ded30fa8d8acc23406a0c192e4f153c004022e96c7010716b1bdc2e108652b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ded30fa8d8acc23406a0c192e4f153c004022e96c7010716b1bdc2e108652b6->enter($__internal_3ded30fa8d8acc23406a0c192e4f153c004022e96c7010716b1bdc2e108652b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3ded30fa8d8acc23406a0c192e4f153c004022e96c7010716b1bdc2e108652b6->leave($__internal_3ded30fa8d8acc23406a0c192e4f153c004022e96c7010716b1bdc2e108652b6_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_29d0a8eccac0c74d9d35aa00ed3d31f623ff8915a10e538de02e116a930872cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29d0a8eccac0c74d9d35aa00ed3d31f623ff8915a10e538de02e116a930872cf->enter($__internal_29d0a8eccac0c74d9d35aa00ed3d31f623ff8915a10e538de02e116a930872cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_29d0a8eccac0c74d9d35aa00ed3d31f623ff8915a10e538de02e116a930872cf->leave($__internal_29d0a8eccac0c74d9d35aa00ed3d31f623ff8915a10e538de02e116a930872cf_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_ab47f7a00cfe7a3c621ccb63b6552f29d7140fe00e41f429246393e1bbdea2fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab47f7a00cfe7a3c621ccb63b6552f29d7140fe00e41f429246393e1bbdea2fd->enter($__internal_ab47f7a00cfe7a3c621ccb63b6552f29d7140fe00e41f429246393e1bbdea2fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_ab47f7a00cfe7a3c621ccb63b6552f29d7140fe00e41f429246393e1bbdea2fd->leave($__internal_ab47f7a00cfe7a3c621ccb63b6552f29d7140fe00e41f429246393e1bbdea2fd_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/Users/vu/projects/phpbot/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
