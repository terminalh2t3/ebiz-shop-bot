<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_f545595115687d7ed2aa66cb0ce4caa35974271ff400b6f173f5a4bbdacda6d3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed127bc2b37c1e31e7d5283d744a88ff247717a6c194f73dbef1a83c30c1123e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed127bc2b37c1e31e7d5283d744a88ff247717a6c194f73dbef1a83c30c1123e->enter($__internal_ed127bc2b37c1e31e7d5283d744a88ff247717a6c194f73dbef1a83c30c1123e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_ed127bc2b37c1e31e7d5283d744a88ff247717a6c194f73dbef1a83c30c1123e->leave($__internal_ed127bc2b37c1e31e7d5283d744a88ff247717a6c194f73dbef1a83c30c1123e_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_8c3eb09406070ed703ca82eb3ec3443eaaf15b7b9d50617b5278768ddd57ff1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c3eb09406070ed703ca82eb3ec3443eaaf15b7b9d50617b5278768ddd57ff1f->enter($__internal_8c3eb09406070ed703ca82eb3ec3443eaaf15b7b9d50617b5278768ddd57ff1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_8c3eb09406070ed703ca82eb3ec3443eaaf15b7b9d50617b5278768ddd57ff1f->leave($__internal_8c3eb09406070ed703ca82eb3ec3443eaaf15b7b9d50617b5278768ddd57ff1f_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/Users/vu/projects/phpbot/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
