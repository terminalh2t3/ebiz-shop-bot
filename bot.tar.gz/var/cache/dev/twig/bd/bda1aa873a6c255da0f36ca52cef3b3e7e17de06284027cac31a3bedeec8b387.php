<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_b6d0cd2008afda9e72bf292b09ff9aba9e089f53a8620393b4e731ac68514ee8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3afac198f0d1a62b5b423b1abc9f1958843334ab22ab0cac7d8e95b4bfecec7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3afac198f0d1a62b5b423b1abc9f1958843334ab22ab0cac7d8e95b4bfecec7f->enter($__internal_3afac198f0d1a62b5b423b1abc9f1958843334ab22ab0cac7d8e95b4bfecec7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_3afac198f0d1a62b5b423b1abc9f1958843334ab22ab0cac7d8e95b4bfecec7f->leave($__internal_3afac198f0d1a62b5b423b1abc9f1958843334ab22ab0cac7d8e95b4bfecec7f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "/Users/vu/projects/phpbot/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/repeated_row.html.php");
    }
}
