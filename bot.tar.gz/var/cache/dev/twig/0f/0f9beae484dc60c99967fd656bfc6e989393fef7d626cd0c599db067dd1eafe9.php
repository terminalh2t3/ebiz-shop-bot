<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_8108f5d1ee36c3878b2175a55b3d302e34d4747217b0f55cddfb625da60cfabe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1feae9191c6d73da1e22b5d1c35f83d97a95b6482b3004cc6f499a7e4e867b05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1feae9191c6d73da1e22b5d1c35f83d97a95b6482b3004cc6f499a7e4e867b05->enter($__internal_1feae9191c6d73da1e22b5d1c35f83d97a95b6482b3004cc6f499a7e4e867b05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1feae9191c6d73da1e22b5d1c35f83d97a95b6482b3004cc6f499a7e4e867b05->leave($__internal_1feae9191c6d73da1e22b5d1c35f83d97a95b6482b3004cc6f499a7e4e867b05_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_d168bfb62dae36f15900649b6ec8979081966705c2abc4720b930c2c324c1fe8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d168bfb62dae36f15900649b6ec8979081966705c2abc4720b930c2c324c1fe8->enter($__internal_d168bfb62dae36f15900649b6ec8979081966705c2abc4720b930c2c324c1fe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_d168bfb62dae36f15900649b6ec8979081966705c2abc4720b930c2c324c1fe8->leave($__internal_d168bfb62dae36f15900649b6ec8979081966705c2abc4720b930c2c324c1fe8_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3f7b576783072c088c406e424bb433c2c0a7e940f24f4d662147ea329e396edf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f7b576783072c088c406e424bb433c2c0a7e940f24f4d662147ea329e396edf->enter($__internal_3f7b576783072c088c406e424bb433c2c0a7e940f24f4d662147ea329e396edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_3f7b576783072c088c406e424bb433c2c0a7e940f24f4d662147ea329e396edf->leave($__internal_3f7b576783072c088c406e424bb433c2c0a7e940f24f4d662147ea329e396edf_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c187ca271a3e869e14c2d509d7248ee96d6486a86baffe135a51efe0b9a04ab6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c187ca271a3e869e14c2d509d7248ee96d6486a86baffe135a51efe0b9a04ab6->enter($__internal_c187ca271a3e869e14c2d509d7248ee96d6486a86baffe135a51efe0b9a04ab6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_c187ca271a3e869e14c2d509d7248ee96d6486a86baffe135a51efe0b9a04ab6->leave($__internal_c187ca271a3e869e14c2d509d7248ee96d6486a86baffe135a51efe0b9a04ab6_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "/Users/vu/projects/phpbot/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
